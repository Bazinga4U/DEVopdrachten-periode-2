class Player:
    def __init__(self, heal, damage, lifep):
        self.heal = heal
        self.damage = damage
        self.lifep = lifep
    def Healing(self):
        return self.heal + 1
    def Damaging(self):
        return self.damage - 1
    def life_points(self):
        lifep = 100
        if Healing >= +1
            lifep + 1
        else:
            Damaging >= -1
            lifep -1
