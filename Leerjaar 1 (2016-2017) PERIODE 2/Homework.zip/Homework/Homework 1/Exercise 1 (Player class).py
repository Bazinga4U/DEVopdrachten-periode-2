class Player:
    def __init__(self,name,x,y):
        self.Name = name
m = Player("Tim")
n = Player("Tom")
o = Player("Gerard")
print(p.Name)