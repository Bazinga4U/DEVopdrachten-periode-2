class Position:
    def __init__(self,x,y):
        self.X = x
        self.Y = y
a = Position(2.5,4.0)
b = Position(3.0,6.0)
c = Position(5.0,2.5)
print(a.X, a.Y)