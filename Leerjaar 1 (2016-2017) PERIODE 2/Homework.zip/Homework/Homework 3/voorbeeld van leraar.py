l = Node(4,Node(3,Empty()))
def printList(l):
    x = l
    l = l.list

def bar(l):
