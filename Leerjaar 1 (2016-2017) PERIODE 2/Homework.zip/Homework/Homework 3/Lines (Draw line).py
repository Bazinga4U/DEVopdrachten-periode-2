def draw_line (n) :
    res =""
    while (( n > 3 )):
        res =( res + "*")
        n =( n - 1)
    return n

res = draw_line (3)
print (draw_line)

draw_line(6)
